
# Final Convenience Patch — Consolidated Auth (drop‑in)

This merges *all* layers into a single `server/auth-routes.ts` and ships the exact React pages/components you need.

## What you get
- Email/password login, cookie sessions
- Admin enforcement:
  - `ENFORCE_2FA_FOR_ADMINS=true` → admins must pass 2FA
  - `ENFORCE_ADMIN_TOTP_SETUP=true` → admins **must enable TOTP** before finishing login (no fallback)
- TOTP 2FA (QR + verify), backup codes (hashed), email/SMS OTP fallback
- Trusted devices (httpOnly cookie, hashed record, TTL via `TRUSTED_DEVICE_DAYS`)
- Password reset (email token, 30 min)
- Admin users list/update
- Account: set phone, enable/disable TOTP, generate/download backup codes PDF, manage trusted devices

## Files in this patch
- `server/auth-routes.ts` (all endpoints)
- `server/security/*` (password, crypto AES-GCM, TOTP, device helpers)
- `server/email.ts`, `server/sms.ts`, `server/export.ts`
- `server/types/session.d.ts`
- `client/src/components/auth/private-route.tsx`
- `client/src/components/layout/header.tsx`
- Pages: `login.tsx`, `2fa.tsx`, `2fa-fallback.tsx`, `forgot.tsx`, `reset.tsx`, `account-security.tsx`, `devices.tsx`
- Router snippet: `client/src/App.ROUTES.MERGED.txt`
- Schema additions: `shared/schema.MERGE_ADD.ts` (merge into your `shared/schema.ts` and run `npm run db:push`)

## .env (minimum)
```
# URLs
APP_URL=https://your-app-url

# Sessions / crypto
SESSION_SECRET=change-me-long
AUTH_ENC_KEY=<32+ char key>  # openssl rand -base64 32
TOTP_ISSUER=AttorneyLeads

# Admin enforcement
ENFORCE_2FA_FOR_ADMINS=true
ENFORCE_ADMIN_TOTP_SETUP=true

# Trusted devices
TRUSTED_DEVICE_DAYS=30
DEVICE_COOKIE_NAME=device

# Email (optional for real emails; otherwise logs to console)
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
SMTP_FROM="Attorney Leads <no-reply@yourdomain.com>"

# SMS (optional; otherwise logs to console)
TWILIO_SID=
TWILIO_TOKEN=
TWILIO_FROM=+15551234567
```

## Install (one-time)
```
npm i pdfkit nodemailer
```
*(Both are optional; without them, the system still works — reset emails and PDFs fall back to console/text.)*

## Wire it up
1. **Schema:** merge `shared/schema.MERGE_ADD.ts` into your Drizzle schema; run `npm run db:push`.
2. **Server:** copy `server/auth-routes.ts` and helper files; ensure `setupSession(app)` is already in your `server/index.ts` (from earlier patch).
3. **Client:** copy pages/components; add routes from `client/src/App.ROUTES.MERGED.txt` to your router.
4. **Header:** replace with the provided header or add the buttons/links manually.
5. **Env:** set the variables shown above. Restart.

That’s it — drop-in and run.
