
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { Link } from "wouter";

export function Header() {
  const [me, setMe] = useState<{ email: string; role: "user" | "admin" } | null>(null);
  useEffect(() => {
    fetch("/api/auth/whoami", { credentials: "include" })
      .then(async (r) => (r.ok ? (await r.json()).user : null))
      .then((u) => setMe(u))
      .catch(() => setMe(null));
  }, []);

  return (
    <header className="flex items-center justify-between px-4 py-2 border-b">
      <nav className="flex gap-3 items-center">
        <Link href="/"><a className="font-semibold">App</a></Link>
        {/* Add your left-side nav items here */}
      </nav>
      <div className="flex items-center gap-2">
        {me ? (
          <>
            <Link href="/account/security"><Button variant="outline" className="mr-1">Account</Button></Link>
            {me.role === "admin" && <Link href="/admin/users"><Button variant="outline" className="mr-1">Admin</Button></Link>}
            <span className="text-sm mr-2">{me.email}</span>
            <Button
              variant="secondary"
              onClick={async () => { await fetch("/api/auth/logout", { method: "POST", credentials: "include" }); window.location.href = "/login"; }}
            >
              Logout
            </Button>
          </>
        ) : (
          <Link href="/login"><Button>Login</Button></Link>
        )}
      </div>
    </header>
  );
}
