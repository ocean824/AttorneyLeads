
import { useEffect, useState } from "react";
import { PrivateRoute } from "@/components/auth/private-route";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";

type Device = {
  id: string;
  label: string | null;
  ip: string | null;
  userAgent: string | null;
  createdAt: string;
  expiresAt: string;
  revokedAt: string | null;
};

export default function Devices() {
  const [list, setList] = useState<Device[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const r = await fetch("/api/account/devices", { credentials: "include" });
    if (r.ok) setList(await r.json());
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function revoke(id: string) {
    const r = await fetch(`/api/account/devices/${id}/revoke`, { method: "POST", credentials: "include" });
    if (r.ok) load();
  }

  return (
    <PrivateRoute>
      <div className="p-6">
        <Card>
          <CardHeader><CardTitle>Trusted Devices</CardTitle></CardHeader>
          <CardContent>
            {loading ? "Loading…" : (
              <table className="w-full text-sm">
                <thead><tr className="text-left border-b"><th>Label</th><th>IP</th><th>Agent</th><th>Expires</th><th>Status</th><th></th></tr></thead>
                <tbody>
                  {list.map(d => (
                    <tr key={d.id} className="border-b">
                      <td>{d.label || "—"}</td>
                      <td>{d.ip || "—"}</td>
                      <td className="truncate max-w-[320px]">{d.userAgent || "—"}</td>
                      <td>{new Date(d.expiresAt).toLocaleString()}</td>
                      <td>{d.revokedAt ? "Revoked" : "Active"}</td>
                      <td className="text-right">
                        {!d.revokedAt && <Button variant="outline" size="sm" onClick={() => revoke(d.id)}>Revoke</Button>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </CardContent>
        </Card>
      </div>
    </PrivateRoute>
  );
}
