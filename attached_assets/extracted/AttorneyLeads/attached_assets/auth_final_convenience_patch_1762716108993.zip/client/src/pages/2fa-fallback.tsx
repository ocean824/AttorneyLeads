
import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";

export default function Fallback2FA() {
  const [, navigate] = useLocation();
  const [sending, setSending] = useState<"email" | "sms" | null>(null);
  const [sentTo, setSentTo] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [trust, setTrust] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function send(channel: "email" | "sms") {
    setSending(channel); setError(null);
    try {
      const r = await fetch("/api/auth/otp/send", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ channel }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Failed to send code");
      setSentTo(j.to || channel);
    } catch (e: any) { setError(e.message); }
    finally { setSending(null); }
  }
  async function verify() {
    setError(null);
    const r = await fetch("/api/auth/otp/verify", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ code }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return setError(j.error || "Invalid code");
    if (trust) await fetch("/api/auth/trust-device?label=My%20Device", { method: "POST", credentials: "include" });
    navigate("/");
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-6">
      <Card className="w-full max-w-md">
        <CardHeader><CardTitle>Verify your sign‑in</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button disabled={!!sending} onClick={() => send("email")}>Send Email Code</Button>
            <Button variant="outline" disabled={!!sending} onClick={() => send("sms")}>Send SMS Code</Button>
          </div>
          {sentTo && <div className="text-sm text-muted-foreground">Code sent to {sentTo}</div>}
          <Input placeholder="6‑digit code" value={code} onChange={(e)=>setCode(e.target.value)} />
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={trust} onChange={(e)=>setTrust(e.target.checked)} /> Trust this device</label>
          {error && <div className="text-sm text-red-600">{error}</div>}
          <Button onClick={verify} className="w-full">Verify</Button>
          <div className="text-xs text-muted-foreground">Tip: You can also use a backup code.</div>
        </CardContent>
      </Card>
    </div>
  );
}
