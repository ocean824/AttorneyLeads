
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";

export default function TwoFA() {
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<"verify" | "setup">("verify");
  const [qr, setQr] = useState<{ qrImageUrl: string; secretBase32: string } | null>(null);
  const [token, setToken] = useState("");
  const [trust, setTrust] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const u = new URL(window.location.href);
    setMode(u.searchParams.get("mode") === "setup" ? "setup" : "verify");
  }, []);

  useEffect(() => {
    if (mode === "setup") {
      fetch("/api/auth/totp/pending/start", { method: "POST", credentials: "include" })
        .then(async (r) => r.ok ? r.json() : Promise.reject())
        .then(setQr)
        .catch(() => setQr(null));
    }
  }, [mode]);

  async function maybeTrust() {
    if (!trust) return;
    await fetch("/api/auth/trust-device?label=My%20Device", { method: "POST", credentials: "include" });
  }

  async function onVerify() {
    setError(null);
    const r = await fetch("/api/auth/totp/login-verify", {
      method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
      body: JSON.stringify({ token }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return setError(j.error || "Invalid code");
    await maybeTrust();
    navigate("/");
  }

  async function onVerifySetup() {
    setError(null);
    const r = await fetch("/api/auth/totp/pending/verify", {
      method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
      body: JSON.stringify({ token }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return setError(j.error || "Invalid code");
    await maybeTrust();
    navigate("/");
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-6">
      <Card className="w-full max-w-md">
        <CardHeader><CardTitle>{mode === "setup" ? "Set up Two‑Factor Authentication" : "Two‑Factor Authentication"}</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          {mode === "setup" ? (
            <>
              <div className="text-sm">Scan this QR code in your authenticator app, then enter the 6‑digit code.</div>
              {qr && <img src={qr.qrImageUrl} alt="TOTP QR" className="border rounded p-2 w-64 h-64" />}
              {qr && <div className="text-xs break-all">Secret: <b>{qr.secretBase32}</b></div>}
              <Input inputMode="numeric" pattern="[0-9]*" placeholder="6‑digit code" value={token} onChange={(e)=>setToken(e.target.value)} />
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={trust} onChange={(e)=>setTrust(e.target.checked)} /> Trust this device</label>
              {error && <div className="text-sm text-red-600">{error}</div>}
              <Button onClick={onVerifySetup} className="w-full">Enable & Continue</Button>
            </>
          ) : (
            <>
              <Input inputMode="numeric" pattern="[0-9]*" placeholder="6‑digit code" value={token} onChange={(e)=>setToken(e.target.value)} />
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={trust} onChange={(e)=>setTrust(e.target.checked)} /> Trust this device</label>
              {error && <div className="text-sm text-red-600">{error}</div>}
              <div className="flex gap-2">
                <Button onClick={onVerify} className="flex-1">Verify</Button>
                <a className="text-sm underline self-center" href="/2fa-fallback">Use Email/SMS</a>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
