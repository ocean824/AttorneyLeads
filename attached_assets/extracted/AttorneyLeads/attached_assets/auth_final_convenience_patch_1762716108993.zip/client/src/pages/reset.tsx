
import { FormEvent, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";

export default function Reset() {
  const [token, setToken] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [ok, setOk] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { const u = new URL(window.location.href); setToken(u.searchParams.get("token")); }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError(null);
    try {
      const res = await fetch("/api/auth/reset-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, password }) });
      const j = await res.json().catch(()=>({}));
      if (!res.ok) throw new Error(j.error || "Reset failed");
      setOk(true);
    } catch (err: any) { setError(err.message); }
    finally { setBusy(false); }
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-6">
      <Card className="w-full max-w-md">
        <CardHeader><CardTitle>Choose a new password</CardTitle></CardHeader>
        <CardContent>
          {ok ? (<div className="space-y-2"><p>Password updated. You can now <a href="/login" className="underline">sign in</a>.</p></div>) : (
            <form onSubmit={onSubmit} className="space-y-4">
              <div><label className="block text-sm mb-1">New password</label>
                <Input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required />
              </div>
              {error && <div className="text-sm text-red-600">{error}</div>}
              <Button type="submit" disabled={busy || !token} className="w-full">{busy ? "Saving…" : "Update password"}</Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
