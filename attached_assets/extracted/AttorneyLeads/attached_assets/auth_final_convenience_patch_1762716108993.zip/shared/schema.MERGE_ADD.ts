
// Merge these additions into your shared/schema.ts (Drizzle).
// Tables/columns required by consolidated auth:

// USERS (ensure these additional columns exist)
/*
  totpEnabled: integer("totp_enabled").notNull().default(0),
  totpSecretEnc: text("totp_secret_enc"),
  phone: varchar("phone", { length: 32 }),
*/

// PASSWORD RESET TOKENS
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  tokenHash: varchar("token_hash", { length: 256 }).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;

// BACKUP CODES
export const userBackupCodes = pgTable("user_backup_codes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  codeHash: varchar("code_hash", { length: 256 }).notNull(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type UserBackupCode = typeof userBackupCodes.$inferSelect;

// TRUSTED DEVICES
export const userTrustedDevices = pgTable("user_trusted_devices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  tokenHash: varchar("token_hash", { length: 256 }).notNull(),
  label: varchar("label", { length: 120 }),
  ip: varchar("ip", { length: 64 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  revokedAt: timestamp("revoked_at"),
});
export type UserTrustedDevice = typeof userTrustedDevices.$inferSelect;
