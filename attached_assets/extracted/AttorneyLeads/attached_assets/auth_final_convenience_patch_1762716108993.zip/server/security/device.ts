
import { createHash, randomBytes } from "crypto";
export function makeDeviceToken(){ const token = randomBytes(24).toString("hex"); const hash = createHash("sha256").update(token).digest("hex"); return { token, hash }; }
export function daysFromEnv(){ const d = Number(process.env.TRUSTED_DEVICE_DAYS || 30); if(!Number.isFinite(d)||d<1)return 30; return Math.min(180, Math.max(1, Math.floor(d))); }
