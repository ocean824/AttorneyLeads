
import { randomBytes, scrypt as _scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";
const scrypt = promisify(_scrypt);
const PARAMS = { N: 16384, r: 8, p: 1 };
const KEYLEN = 64;

function encode(salt: Buffer, hash: Buffer) {
  return `scrypt$N=${PARAMS.N}$r=${PARAMS.r}$p=${PARAMS.p}$${salt.toString("hex")}$${hash.toString("hex")}`;
}
function parse(stored: string) {
  const parts = stored.split("$");
  if (parts[0] !== "scrypt" || parts.length !== 6) throw new Error("Invalid password hash");
  const salt = Buffer.from(parts[4], "hex");
  const hash = Buffer.from(parts[5], "hex");
  const N = Number(parts[1].split("=")[1]);
  const r = Number(parts[2].split("=")[1]);
  const p = Number(parts[3].split("=")[1]);
  return { salt, hash, N, r, p };
}
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const hash = (await scrypt(password, salt, KEYLEN, PARAMS)) as Buffer;
  return encode(salt, hash);
}
export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const { salt, hash, N, r, p } = parse(stored);
  const cand = (await scrypt(password, salt, hash.length, { N, r, p })) as Buffer;
  return cand.length === hash.length && timingSafeEqual(cand, hash);
}
