
import { createHmac, randomBytes } from "crypto";
const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
export function base32Encode(buf: Buffer): string {
  let bits = 0, value = 0, out = "";
  for (const b of buf) { value = (value<<8) | b; bits+=8; while(bits>=5){ out += ALPHABET[(value >>> (bits-5)) & 31]; bits -= 5; } }
  if (bits>0) out += ALPHABET[(value << (5-bits)) & 31];
  return out;
}
export function base32Decode(str: string): Buffer {
  let bits = 0, value = 0; const out: number[] = [];
  for (const c of str.replace(/=+$/,"").toUpperCase()) {
    const idx = ALPHABET.indexOf(c); if (idx === -1) continue;
    value = (value<<5) | idx; bits += 5;
    if (bits>=8){ out.push((value >>> (bits-8)) & 0xff); bits -= 8; }
  }
  return Buffer.from(out);
}
export function generateSecret(bytes=20){ return { secretBase32: base32Encode(randomBytes(bytes)) }; }
function hotp(secret: Buffer, counter: number, digits=6): string {
  const cb = Buffer.alloc(8); for (let i=7;i>=0;i--){ cb[i] = counter & 0xff; counter >>= 8; }
  const h = createHmac("sha1", secret).update(cb).digest();
  const o = h[h.length-1] & 0xf;
  const code = ((h[o] & 0x7f)<<24) | ((h[o+1] & 0xff)<<16) | ((h[o+2] & 0xff)<<8) | (h[o+3] & 0xff);
  return String(code % 10**digits).padStart(digits,"0");
}
export function totp(secretBase32: string, step=30, digits=6, ts=Date.now()){ return hotp(base32Decode(secretBase32), Math.floor(ts/1000/step), digits); }
export function verifyTotp(token: string, secretBase32: string, window=1, step=30, digits=6, ts=Date.now()): boolean {
  token = String(token).trim();
  for(let w=-window; w<=window; w++){ if (totp(secretBase32, step, digits, ts + w*step*1000) === token) return true; }
  return false;
}
export function otpauthURI(issuer: string, account: string, secretBase32: string): string {
  const params = new URLSearchParams({ secret: secretBase32, issuer });
  return `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(account)}?${params.toString()}`;
}
