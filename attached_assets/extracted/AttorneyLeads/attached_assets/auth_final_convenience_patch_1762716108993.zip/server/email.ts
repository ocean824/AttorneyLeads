
type MailInput = { to: string; subject: string; html: string; text?: string };
export async function sendMail(msg: MailInput): Promise<void> {
  const host = process.env.SMTP_HOST;
  const from = process.env.SMTP_FROM || "no-reply@example.com";
  if (host) {
    try {
      const nodemailer = await import("nodemailer");
      const transporter = nodemailer.createTransport({
        host,
        port: Number(process.env.SMTP_PORT || 587),
        secure: !!process.env.SMTP_SECURE,
        auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS || "" } : undefined,
      });
      await transporter.sendMail({ from, to: msg.to, subject: msg.subject, html: msg.html, text: msg.text });
      return;
    } catch (e) { console.warn("nodemailer not available or failed, using console:", (e as Error).message); }
  }
  console.log("==== DEV MAIL ===="); console.log("TO:", msg.to); console.log("SUBJECT:", msg.subject); console.log("HTML:", msg.html);
}
