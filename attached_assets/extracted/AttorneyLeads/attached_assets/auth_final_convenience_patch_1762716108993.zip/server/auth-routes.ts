
import type { Express, Request, Response } from "express";
import { db } from "./db";
import { and, eq } from "drizzle-orm";
import {
  users,
  loginSchema,
  registerUserSchema,
  passwordResetTokens,
  userBackupCodes,
  userTrustedDevices,
  type User,
} from "@shared/schema";
import { hashPassword, verifyPassword } from "./security/password";
import { encryptGCM, decryptGCM } from "./security/crypto";
import { generateSecret, verifyTotp, otpauthURI } from "./security/totp";
import { makeDeviceToken, daysFromEnv } from "./security/device";
import { sendMail } from "./email";
import { sendSms } from "./sms";
import { sendBackupCodesPdf } from "./export";
import { randomBytes, createHash } from "crypto";

const DEVICE_COOKIE = process.env.DEVICE_COOKIE_NAME || "device";

function sanitize(user: User) { const { passwordHash, ...rest } = user as any; return rest; }
function requireAuth(req: Request, res: Response, next: Function){ if(!req.session?.user) return res.status(401).json({error:"Unauthorized"}); next(); }
function requireAdmin(req: Request, res: Response, next: Function){ if(!req.session?.user || req.session.user.role!=="admin") return res.status(403).json({error:"Forbidden"}); next(); }

function maskEmail(email: string){ const [u,d] = email.split("@"); const a = u.length<=2 ? u[0] : u.slice(0,2); return `${a}${"*".repeat(Math.max(1,u.length-2))}@${d}`; }
function maskPhone(phone?: string | null){ if(!phone) return null; const last4 = phone.slice(-4); return `***-***-${last4}`; }
function hashToken(t: string){ return createHash("sha256").update(t).digest("hex"); }
function getCookie(req: Request, name: string): string | null {
  const raw = req.headers.cookie || ""; const parts = raw.split(/;\s*/);
  for (const p of parts){ const [k,...v] = p.split("="); if (decodeURIComponent(k) === name) return decodeURIComponent(v.join("=")); }
  return null;
}
function totpEnabled(u: any){ return !!(u.totpEnabled === 1 || u.totp_enabled === 1); }
function isAdmin(u: any){ return (u.role || "user") === "admin"; }
function enforceAdmins(){ return process.env.ENFORCE_2FA_FOR_ADMINS === "true"; }
function enforceAdminSetup(){ return process.env.ENFORCE_ADMIN_TOTP_SETUP === "true"; }
function appUrl(){ return (process.env.APP_URL || "http://localhost:3000").replace(/\/$/,""); }

async function deviceBypass2FA(req: Request, user: any): Promise<boolean> {
  if (!totpEnabled(user)) return false;
  const cookie = getCookie(req, DEVICE_COOKIE);
  if (!cookie) return false;
  const tokenHash = hashToken(cookie);
  const rows = await db.select().from(userTrustedDevices).where(and(eq(userTrustedDevices.userId, user.id), eq(userTrustedDevices.tokenHash, tokenHash)));
  const d: any = rows[0];
  if (!d || d.revokedAt || new Date(d.expiresAt) < new Date()) return false;
  return true;
}
async function trustThisDevice(res: Response, userId: string, label: string | undefined, ip: string, ua: string) {
  const { token, hash } = makeDeviceToken();
  const days = daysFromEnv();
  const expiresAt = new Date(Date.now() + days*24*3600*1000);
  await db.insert(userTrustedDevices).values({ userId, tokenHash: hash, label, ip, userAgent: ua, expiresAt });
  res.cookie(DEVICE_COOKIE, token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV==="production", maxAge: days*24*3600*1000 });
}

export function registerAuthRoutes(app: Express) {

  // ---- Bootstrap first admin ----
  app.post("/api/auth/bootstrap", async (req, res) => {
    const adminEmail = String(process.env.ADMIN_EMAIL || "").trim();
    const adminPassword = String(process.env.ADMIN_PASSWORD || "").trim();
    if (!adminEmail || !adminPassword) return res.status(400).json({ error: "ADMIN_EMAIL and ADMIN_PASSWORD must be set" });
    const existing = await db.select().from(users);
    if (existing.length > 0) return res.status(409).json({ error: "Users already exist" });
    const passwordHash = await hashPassword(adminPassword);
    const [created] = await db.insert(users).values({ email: adminEmail.toLowerCase(), passwordHash, role: "admin", isActive: 1 }).returning();
    res.json({ message:"Admin created", user: sanitize(created) });
  });

  // ---- Register (admin only) ----
  app.post("/api/auth/register", requireAdmin, async (req, res) => {
    try {
      const body = registerUserSchema.parse(req.body);
      const dup = await db.select().from(users).where(eq(users.email, body.email.toLowerCase()));
      if (dup.length) return res.status(409).json({ error: "Email already in use" });
      const passwordHash = await hashPassword(body.password);
      const [created] = await db.insert(users).values({ email: body.email.toLowerCase(), passwordHash, role: body.role, isActive: 1 }).returning();
      res.json({ user: sanitize(created) });
    } catch (e: any) { res.status(400).json({ error: e.message || "Invalid payload" }); }
  });

  // ---- Login (with admin enforcement, hard gate, device bypass) ----
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      const [user] = await db.select().from(users).where(eq(users.email, email.toLowerCase()));
      if (!user || !user.isActive) return res.status(401).json({ error: "Invalid credentials" });
      const ok = await verifyPassword(password, (user as any).passwordHash);
      if (!ok) return res.status(401).json({ error: "Invalid credentials" });

      // device bypass (only if user already has TOTP enabled)
      if (await deviceBypass2FA(req, user)) {
        await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
        req.session.user = { id: user.id, email: user.email, role: (user as any).role || "user" };
        return res.json({ user: sanitize(user) });
      }

      const admin = isAdmin(user);
      const hasTotp = totpEnabled(user);
      const phone = (user as any).phone || null;
      const enforce = enforceAdmins();
      const hardGate = enforceAdminSetup();

      // Strict admin TOTP setup first
      if (admin && hardGate && !hasTotp) {
        req.session.pending2fa = { userId: user.id, hardSetup: true };
        return res.json({ requires2fa: true, adminMustSetup2fa: true, methods: { totp: true, backup: false, fallback: { email: false, sms: false } } });
      }

      // Admin must do some 2FA (if enforce) or anyone with TOTP enabled
      if ((admin && enforce) || hasTotp) {
        req.session.pending2fa = { userId: user.id };
        return res.json({
          requires2fa: true,
          methods: { totp: hasTotp, backup: true, fallback: { email: true, sms: !!phone } },
          destinations: { email: maskEmail(user.email), phone: maskPhone(phone) }
        });
      }

      // Otherwise normal login
      await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
      req.session.user = { id: user.id, email: user.email, role: (user as any).role || "user" };
      res.json({ user: sanitize(user) });
    } catch (e: any) { res.status(400).json({ error: e.message || "Invalid payload" }); }
  });

  app.post("/api/auth/logout", (req, res) => { req.session?.destroy(()=> res.json({ ok:true })); });
  app.get("/api/auth/whoami", (req, res) => { const u = req.session?.user; if(!u) return res.status(401).json({error:"Unauthorized"}); res.json({ user: u }); });

  // ---- Pending admin hard-setup TOTP ----
  app.post("/api/auth/totp/pending/start", async (req, res) => {
    const p = req.session?.pending2fa;
    if (!p || !p.hardSetup) return res.status(401).json({ error: "No hard-setup pending" });
    const [user] = await db.select().from(users).where(eq(users.id, p.userId));
    if (!user) return res.status(400).json({ error: "Invalid session" });
    const { secretBase32 } = generateSecret();
    (req.session as any).totpSetup = { secretBase32 };
    const uri = otpauthURI(process.env.TOTP_ISSUER || "AttorneyLeads", user.email, secretBase32);
    const qr = `https://chart.googleapis.com/chart?cht=qr&chs=256x256&chl=${encodeURIComponent(uri)}`;
    res.json({ otpauthURI: uri, qrImageUrl: qr, secretBase32 });
  });
  app.post("/api/auth/totp/pending/verify", async (req, res) => {
    const p = req.session?.pending2fa as any;
    const setup = (req.session as any).totpSetup;
    if (!p?.hardSetup || !setup?.secretBase32) return res.status(401).json({ error: "No setup in progress" });
    const token = String(req.body?.token || "");
    if (!token) return res.status(400).json({ error: "Missing token" });
    if (!verifyTotp(token, setup.secretBase32, 1)) return res.status(401).json({ error: "Invalid code" });
    const enc = encryptGCM(setup.secretBase32);
    const [user] = await db.update(users).set({ totpSecretEnc: enc as any, totpEnabled: 1 as any }).where(eq(users.id, p.userId)).returning();
    delete (req.session as any).totpSetup; delete (req.session as any).pending2fa;
    req.session.user = { id: (user as any).id, email: (user as any).email, role: (user as any).role || "user" };
    res.json({ user: sanitize(user!) });
  });

  // ---- Standard TOTP login verify ----
  app.post("/api/auth/totp/login-verify", async (req, res) => {
    const p = req.session?.pending2fa;
    if (!p) return res.status(401).json({ error: "No pending 2FA" });
    const code = String(req.body?.token || "");
    if (!code) return res.status(400).json({ error: "Missing token" });
    const [user] = await db.select().from(users).where(eq(users.id, p.userId));
    if (!user) return res.status(401).json({ error: "Invalid session" });
    const enc = (user as any).totpSecretEnc || (user as any).totp_secret_enc;
    if (!enc) return res.status(400).json({ error: "2FA not set up" });
    const ok = verifyTotp(code, decryptGCM(enc), 1);
    if (!ok) return res.status(401).json({ error: "Invalid code" });
    await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
    req.session.user = { id: user.id, email: user.email, role: (user as any).role || "user" };
    delete (req.session as any).pending2fa;
    res.json({ user: sanitize(user) });
  });

  // ---- Backup codes ----
  app.post("/api/auth/backup-codes/generate", requireAuth, async (req, res) => {
    // delete existing
    await db.delete(userBackupCodes).where(eq(userBackupCodes.userId, req.session!.user!.id));
    function code(){ const b = randomBytes(5).toString("hex").toUpperCase(); return `${b.slice(0,5)}-${b.slice(5)}`; }
    const plain = Array.from({length:10}).map(()=> code());
    await db.insert(userBackupCodes).values(plain.map(c => ({ userId: req.session!.user!.id, codeHash: hashToken(c) })));
    res.json({ codes: plain });
  });
  app.post("/api/auth/backup-codes/verify", async (req, res) => {
    const p = req.session?.pending2fa;
    if (!p) return res.status(401).json({ error: "No pending 2FA" });
    const code = String(req.body?.code || "");
    if (!code) return res.status(400).json({ error: "Code required" });
    const rows = await db.select().from(userBackupCodes).where(and(eq(userBackupCodes.userId, p.userId), eq(userBackupCodes.codeHash, hashToken(code))));
    const entry: any = rows[0];
    if (!entry || entry.usedAt) return res.status(401).json({ error: "Invalid backup code" });
    await db.update(userBackupCodes).set({ usedAt: new Date() }).where(eq(userBackupCodes.id, entry.id));
    const [user] = await db.select().from(users).where(eq(users.id, p.userId));
    await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
    req.session.user = { id: user.id, email: user.email, role: (user as any).role || "user" };
    delete (req.session as any).pending2fa;
    res.json({ user: sanitize(user) });
  });
  app.post("/api/auth/backup-codes/pdf", requireAuth, async (req, res) => {
    const codes: string[] = Array.isArray(req.body?.codes) ? req.body.codes.map(String) : [];
    if (!codes.length) return res.status(400).json({ error: "No codes" });
    await sendBackupCodesPdf(res, req.session!.user!.email, codes);
  });

  // ---- OTP fallback (Email/SMS) ----
  app.post("/api/auth/otp/send", async (req, res) => {
    const p = req.session?.pending2fa;
    if (!p) return res.status(401).json({ error: "No pending 2FA" });
    const channel = String(req.body?.channel || "email");
    const [user] = await db.select().from(users).where(eq(users.id, p.userId));
    if (!user) return res.status(401).json({ error: "Invalid session" });
    const token = (Math.floor(100000 + Math.random()*900000)).toString();
    (req.session as any).pending2faOtp = { hash: hashToken(token), expiresAt: Date.now()+10*60*1000 };
    if (channel === "sms") {
      const phone = (user as any).phone || null;
      if (!phone) return res.status(400).json({ error: "No phone on file" });
      await sendSms(phone, `Your verification code is ${token}`);
      return res.json({ sent: true, channel: "sms", to: maskPhone(phone) });
    } else {
      await sendMail({ to: user.email, subject: "Your verification code", html: `<p>Your code is <b>${token}</b> (10 min).</p>`, text: `Your code is ${token} (10 min).` });
      return res.json({ sent: true, channel: "email", to: maskEmail(user.email) });
    }
  });
  app.post("/api/auth/otp/verify", async (req, res) => {
    const p = req.session?.pending2fa; const otp = (req.session as any)?.pending2faOtp;
    if (!p || !otp) return res.status(401).json({ error: "No pending OTP" });
    const code = String(req.body?.code || "");
    if (!code) return res.status(400).json({ error: "Code required" });
    if (Date.now() > otp.expiresAt) return res.status(401).json({ error: "Code expired" });
    if (hashToken(code) !== otp.hash) return res.status(401).json({ error: "Invalid code" });
    const [user] = await db.select().from(users).where(eq(users.id, p.userId));
    await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
    req.session.user = { id: user.id, email: user.email, role: (user as any).role || "user" };
    delete (req.session as any).pending2fa; delete (req.session as any).pending2faOtp;
    res.json({ user: sanitize(user) });
  });

  // ---- TOTP management (account) ----
  app.post("/api/auth/totp/status", requireAuth, async (req, res) => {
    const [user] = await db.select().from(users).where(eq(users.id, req.session!.user!.id));
    res.json({ enabled: totpEnabled(user) });
  });
  app.post("/api/auth/totp/setup/start", requireAuth, async (req, res) => {
    const [user] = await db.select().from(users).where(eq(users.id, req.session!.user!.id));
    const { secretBase32 } = generateSecret();
    (req.session as any).totpSetup = { secretBase32 };
    const uri = otpauthURI(process.env.TOTP_ISSUER || "AttorneyLeads", user.email, secretBase32);
    const qr = `https://chart.googleapis.com/chart?cht=qr&chs=256x256&chl=${encodeURIComponent(uri)}`;
    res.json({ otpauthURI: uri, qrImageUrl: qr, secretBase32 });
  });
  app.post("/api/auth/totp/setup/verify", requireAuth, async (req, res) => {
    const setup = (req.session as any).totpSetup;
    if (!setup?.secretBase32) return res.status(400).json({ error: "No setup in progress" });
    const token = String(req.body?.token || "");
    if (!token) return res.status(400).json({ error: "Missing token" });
    if (!verifyTotp(token, setup.secretBase32, 1)) return res.status(401).json({ error: "Invalid code" });
    const enc = encryptGCM(setup.secretBase32);
    const [user] = await db.update(users).set({ totpSecretEnc: enc as any, totpEnabled: 1 as any }).where(eq(users.id, req.session!.user!.id)).returning();
    delete (req.session as any).totpSetup;
    res.json({ enabled: true, user: sanitize(user!) });
  });
  app.post("/api/auth/totp/disable", requireAuth, async (req, res) => {
    const { password } = req.body || {};
    if (!password) return res.status(400).json({ error: "Password required" });
    const [user] = await db.select().from(users).where(eq(users.id, req.session!.user!.id));
    const ok = await verifyPassword(password, (user as any).passwordHash);
    if (!ok) return res.status(401).json({ error: "Invalid password" });
    const [updated] = await db.update(users).set({ totpSecretEnc: null as any, totpEnabled: 0 as any }).where(eq(users.id, user.id)).returning();
    res.json({ enabled: false, user: sanitize(updated!) });
  });

  // ---- Device management ----
  app.get("/api/account/devices", requireAuth, async (req, res) => {
    const rows = await db.select().from(userTrustedDevices).where(eq(userTrustedDevices.userId, req.session!.user!.id));
    res.json(rows);
  });
  app.post("/api/account/devices/:id/revoke", requireAuth, async (req, res) => {
    const id = req.params.id;
    const [row] = await db.update(userTrustedDevices).set({ revokedAt: new Date() }).where(and(eq(userTrustedDevices.id, id), eq(userTrustedDevices.userId, req.session!.user!.id))).returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  });
  app.post("/api/auth/trust-device", async (req, res) => {
    const u = req.session?.user || (req.session as any)?.pending2fa;
    if (!u) return res.status(401).json({ error: "Unauthorized" });
    const label = String(req.query.label || "");
    await trustThisDevice(res, (u as any).userId || (u as any).id, label || undefined, (req.headers["x-forwarded-for"] as string || req.socket.remoteAddress || "").toString(), String(req.headers["user-agent"] || ""));
    res.json({ trusted: true, days: daysFromEnv() });
  });

  // ---- Password reset ----
  app.post("/api/auth/request-password-reset", async (req, res) => {
    const email = String(req.body?.email || "").toLowerCase();
    if (!email) return res.status(400).json({ error: "Email required" });
    const [user] = await db.select().from(users).where(eq(users.email, email));
    if (!user) return res.json({ ok: true });
    const token = randomBytes(32).toString("hex");
    await db.insert(passwordResetTokens).values({ userId: user.id, tokenHash: hashToken(token), expiresAt: new Date(Date.now()+30*60*1000) });
    const url = `${appUrl()}/reset?token=${token}`;
    await sendMail({ to: email, subject: "Password Reset", html: `<p>Reset your password: <a href="${url}">link</a> (30 min)</p>`, text: `Reset: ${url}` });
    res.json({ ok: true });
  });
  app.post("/api/auth/reset-password", async (req, res) => {
    const token = String(req.body?.token || ""); const password = String(req.body?.password || "");
    if (!token || !password) return res.status(400).json({ error: "Token and password required" });
    const rows = await db.select().from(passwordResetTokens).where(eq(passwordResetTokens.tokenHash, hashToken(token)));
    const entry: any = rows[0];
    if (!entry || entry.usedAt || new Date(entry.expiresAt) < new Date()) return res.status(400).json({ error: "Invalid or expired token" });
    const [user] = await db.select().from(users).where(eq(users.id, entry.userId));
    if (!user) return res.status(400).json({ error: "Invalid token" });
    const passwordHash = await hashPassword(password);
    await db.update(users).set({ passwordHash }).where(eq(users.id, user.id));
    await db.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, entry.id));
    res.json({ ok: true });
  });

  // ---- Admin user ops ----
  app.get("/api/admin/users", requireAdmin, async (_req, res) => {
    const list = await db.select().from(users).orderBy(users.createdAt);
    res.json(list.map(sanitize));
  });
  app.patch("/api/admin/users/:id", requireAdmin, async (req, res) => {
    const id = req.params.id; const updates: any = {};
    if (typeof req.body.role === "string") updates.role = req.body.role;
    if (typeof req.body.isActive === "number") updates.isActive = req.body.isActive;
    if (typeof req.body.phone === "string") updates.phone = req.body.phone;
    const [u] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    if (!u) return res.status(404).json({ error: "Not found" });
    res.json(sanitize(u));
  });

  // ---- Account phone ----
  app.post("/api/account/phone", requireAuth, async (req, res) => {
    const phone = String(req.body?.phone || "");
    if (!/^[+0-9 \-()]{7,32}$/.test(phone)) return res.status(400).json({ error: "Invalid phone" });
    const [u] = await db.update(users).set({ phone }).where(eq(users.id, req.session!.user!.id)).returning();
    res.json({ ok: true, phone: (u as any).phone });
  });
}
