
import type { Response } from "express";
export async function sendBackupCodesPdf(res: Response, email: string, codes: string[]) {
  try {
    const PDFDocument = (await import("pdfkit")).default as any;
    const doc = new PDFDocument({ size: "A4", margin: 50 });
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="backup-codes-${Date.now()}.pdf"`);
    doc.pipe(res as any);
    doc.fontSize(20).text("Backup Codes"); doc.moveDown(0.5);
    doc.fontSize(12).text(`Account: ${email}`); doc.moveDown(1);
    for (const c of codes) doc.fontSize(16).text(`• ${c}`);
    doc.moveDown(1); doc.fontSize(10).text("Each code can be used once. Keep them safe.");
    doc.end();
  } catch {
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="backup-codes-${Date.now()}.txt"`);
    res.end(["Backup Codes", `Account: ${email}`, "", ...codes].join("\n"));
  }
}
