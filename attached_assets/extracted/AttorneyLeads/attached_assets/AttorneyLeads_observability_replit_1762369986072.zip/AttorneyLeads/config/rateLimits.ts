export type RateLimitConfig = {
  windowMs: number;
  max: number;
};

export type RouteRateLimitMap = {
  [routeKey: string]: RateLimitConfig;
};

export const routeRateLimits: RouteRateLimitMap = {
  "GET /api/stats": { windowMs: 15 * 60 * 1000, max: 100 },
  "GET /api/analytics": { windowMs: 15 * 60 * 1000, max: 60 },
  "GET /api/records": { windowMs: 15 * 60 * 1000, max: 120 },

  "POST /api/scrape/start": { windowMs: 15 * 60 * 1000, max: 10 },
  "POST /api/ai/enhance": { windowMs: 15 * 60 * 1000, max: 10 },
  "POST /api/crm/discover": { windowMs: 15 * 60 * 1000, max: 10 },
  "POST /api/crm/outreach/send": { windowMs: 15 * 60 * 1000, max: 10 },
  "POST /api/crm/sheets/sync-prospects": { windowMs: 15 * 60 * 1000, max: 10 },
  "POST /api/crm/sheets/sync-records": { windowMs: 15 * 60 * 1000, max: 10 },

  DEFAULT: { windowMs: 15 * 60 * 1000, max: 100 },
};
