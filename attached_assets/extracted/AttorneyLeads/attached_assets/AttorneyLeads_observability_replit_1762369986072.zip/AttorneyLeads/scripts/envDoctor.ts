import { z } from "zod";

const envSchema = z.object({
  DATABASE_URL: z.string().url(),
  AI_INTEGRATIONS_OPENAI_API_KEY: z.string().min(1),
  AI_INTEGRATIONS_OPENAI_BASE_URL: z.string().url(),
});

const result = envSchema.safeParse(process.env);

if (!result.success) {
  // eslint-disable-next-line no-console
  console.error("Missing or invalid environment variables:", result.error.format());
  process.exit(1);
}

// eslint-disable-next-line no-console
console.log("Environment variables look good.");
