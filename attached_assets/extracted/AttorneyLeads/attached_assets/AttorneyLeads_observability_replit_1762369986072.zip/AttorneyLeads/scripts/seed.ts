import { db } from "../server/db";
import { arrestRecords } from "@shared/schema";

async function main() {
  // Seed a single sample arrest record if table is empty
  const existing = await db.select().from(arrestRecords).limit(1);
  if (existing.length > 0) {
    console.log("Seed skipped: records already exist.");
    return;
  }

  await db.insert(arrestRecords).values({
    fullName: "DOE, JOHN",
    firstName: "JOHN",
    lastName: "DOE",
    bookingDate: new Date().toISOString().slice(0, 10),
    charges: "SAMPLE - POSS SESSION",
    bondAmount: "2500",
    inmateId: "SAMPLE-001",
    county: "Sample County",
    sourceSystem: "seed",
  } as any);

  console.log("Seed completed: inserted sample arrest record.");
}

main().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
