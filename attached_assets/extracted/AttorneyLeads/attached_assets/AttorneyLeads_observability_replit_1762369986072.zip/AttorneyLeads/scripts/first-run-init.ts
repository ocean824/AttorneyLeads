import { execSync } from "child_process";

function run(cmd: string) {
  console.log(`> ${cmd}`);
  execSync(cmd, { stdio: "inherit" });
}

async function main() {
  try {
    run("npm run env:check");
    run("npm run db:push");
    run("npm run seed");
    console.log("\nFirst-run initialization complete.");
    console.log("You can now run `npm run dev` and open the Replit webview.");
  } catch (err) {
    console.error("First-run initializer failed:", err);
    process.exit(1);
  }
}

main();
