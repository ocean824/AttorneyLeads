import http from "http";
import { db } from "../server/db";
import { arrestRecords } from "@shared/schema";

async function checkDb() {
  const records = await db.select().from(arrestRecords).limit(1);
  console.log("DB check ok, sample rows:", records.length);
}

function checkEndpoint(path: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const req = http.get(
      {
        host: "127.0.0.1",
        port: parseInt(process.env.PORT || "5000", 10),
        path,
      },
      (res) => {
        console.log(`Smoke: ${path} ->`, res.statusCode);
        if (res.statusCode && res.statusCode < 500) {
          resolve();
        } else {
          reject(new Error(`Endpoint ${path} returned ${res.statusCode}`));
        }
      }
    );

    req.on("error", reject);
  });
}

async function main() {
  await checkDb();
  await checkEndpoint("/healthz");
  await checkEndpoint("/readyz");
  console.log("Smoke test passed.");
}

main().catch((err) => {
  console.error("Smoke test failed:", err);
  process.exit(1);
});
