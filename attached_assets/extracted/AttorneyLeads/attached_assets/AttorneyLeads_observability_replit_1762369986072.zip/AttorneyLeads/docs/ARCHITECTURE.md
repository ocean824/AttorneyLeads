# Architecture

## Overview

AttorneyLeads is a single Replit workspace application composed of:

- **client/** – React + Vite SPA for dashboard, records, duplicates, CRM, analytics.
- **server/** – Express API server that:
  - Handles REST endpoints under `/api/**`.
  - Hosts observability endpoints under `/healthz`, `/readyz`, `/metrics`.
  - Serves the built SPA in production via `vite.ts` helpers.
- **shared/** – Drizzle schema & zod validation shared between server and (optionally) client.

## Key Dependencies

- Runtime: Node.js 20
- DB: Neon Postgres (via `@neondatabase/serverless` and Drizzle ORM)
- AI: OpenAI through Replit AI integrations
- Integrations: PhantomBuster, Calendly, Google Sheets

## Observability

- `/healthz` – basic DB connectivity check.
- `/readyz` – readiness check including DB, basic env validation, and counts of core tables.
- `/metrics` – Prometheus-compatible text endpoint with basic gauges/counters.

The implementation lives in `server/observability.ts` and can be wired into the Express
app via a helper function `registerObservabilityRoutes(app)`.
