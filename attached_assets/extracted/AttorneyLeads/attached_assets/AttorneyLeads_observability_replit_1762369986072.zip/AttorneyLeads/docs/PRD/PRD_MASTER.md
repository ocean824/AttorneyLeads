# AttorneyLeads – PRD MASTER

## 1. Scope & Vision

AttorneyLeads is a lead-generation and intake acceleration tool for criminal
defense attorneys. It monitors public arrest records, enriches them with AI,
deduplicates and scores leads, and supports outbound outreach and scheduling.

## 2. Personas

- **Criminal Defense Attorney**
- **Intake Specialist / Coordinator**
- **Owner / Operator**

## 3. Core User Flows

1. Configure and start county scrapes.
2. Review and deduplicate records.
3. Launch outreach and book consults.
4. Monitor performance via analytics.

## 4. Non-Functional Requirements

- Single Replit workspace.
- Node 20 + Postgres (Neon).
- OpenAI for enrichment via Replit AI integrations.
- Basic observability via `/healthz`, `/readyz`, `/metrics`.

## 5. AI Enhancement Overview

- Charge classification, risk scoring, normalization.
- Lead scoring inputs and narrative explanations.
