# Feature PRD – Lead Scraping & Intake

## Problem

Attorneys need a reliable, automated way to ingest new arrest records from
county sources without manual monitoring.

## Goals

- Start a scrape flow in < 30 seconds.
- Ingest and enrich new records quickly.
- Provide high-level job status and basic analytics.

## Acceptance Criteria (Sketch)

- `POST /api/scrape/start` starts a job.
- `GET /api/scrape/jobs` lists jobs.
- `GET /api/records` returns paginated records.

## AI Behavior

- Batch enrichment after scrape completion using OpenAI.
