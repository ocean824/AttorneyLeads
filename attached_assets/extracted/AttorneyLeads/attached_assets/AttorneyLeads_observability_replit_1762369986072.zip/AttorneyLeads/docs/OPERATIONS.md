# Operations

## Environment Variables

| Name                               | Required | Description                                       |
|------------------------------------|----------|---------------------------------------------------|
| `DATABASE_URL`                     | Yes      | Postgres connection string (Neon recommended).    |
| `AI_INTEGRATIONS_OPENAI_API_KEY`   | Yes      | OpenAI API key via Replit AI Integrations.        |
| `AI_INTEGRATIONS_OPENAI_BASE_URL`  | Yes      | OpenAI base URL (Replit AI proxy).                |
| `PHANTOMBUSTER_API_KEY`            | Optional | PhantomBuster API key for prospect discovery.     |
| `PHANTOM_AGENT_ID`                 | Optional | PhantomBuster container/agent ID.                 |
| `CALENDLY_API_KEY`                 | Optional | Calendly API key.                                 |
| `CALENDLY_USER_URI`                | Optional | Calendly user URI for scheduling.                 |
| `GOOGLE_SHEETS_TOKEN`              | Optional | OAuth token/secret for Sheets integration.        |
| `PORT`                             | No       | HTTP port (defaults to 5000 on Replit).          |

## Observability Endpoints

- `GET /healthz`
  - Checks basic DB connectivity by running a lightweight query against `arrest_records`.
  - Returns `{ status: "ok" }` on success, HTTP 500 with `{ status: "error" }` on failure.

- `GET /readyz`
  - Performs a deeper readiness check:
    - DB connectivity
    - Counts `arrest_records` and `scrape_jobs`
    - Ensures `AI_INTEGRATIONS_OPENAI_API_KEY` is set
  - Returns JSON like:
    ```json
    {
      "status": "ok",
      "checks": {
        "db": true,
        "env": {
          "openai": true
        },
        "recordCount": 123,
        "jobCount": 4
      }
    }
    ```

- `GET /metrics`
  - Returns plaintext in Prometheus exposition format with metrics such as:
    - `attorneyleads_up`
    - `attorneyleads_records_total`
    - `attorneyleads_scrape_jobs_total`
  - Content-Type: `text/plain; version=0.0.4`

## Basic Runbook

### First Run

1. Set the following secrets in Replit:
   - `DATABASE_URL`
   - `AI_INTEGRATIONS_OPENAI_API_KEY`
   - `AI_INTEGRATIONS_OPENAI_BASE_URL`
2. In the Shell:
   ```bash
   npm install
   npm run env:check        # validate env vars
   npm run db:push          # create/update schema
   npm run seed             # seed sample data
   npm run dev
   ```
3. Open the webview at `/`.

### Health & Readiness

- Use `/healthz` to check if the app can reach the DB.
- Use `/readyz` before routing traffic to confirm the app is fully ready.

### Smoke Test

- Run `npm run smoke` to:
  - Hit `/healthz` and `/readyz`.
  - Perform a simple DB check.
