# Security Overview – AttorneyLeads

> Assumed: Single-tenant deployment in a private Replit workspace. If you
> expose this as a public SaaS, additional hardening is required.

## AuthN/AuthZ (Planned)

- Roles: Owner, Attorney, Intake Specialist, Analyst.
- Authorization matrix is defined conceptually (see PRDs) and should be
  implemented via a `permissions.ts` module and middleware.

## Input Validation & Output Whitelisting

- All significant endpoints SHOULD validate inputs via zod schemas.
- Responses SHOULD explicitly shape payloads to avoid leaking internal fields.

## Rate Limiting

- Route-level rate limits defined in `config/rateLimits.ts`.
- Implemented via `server/middleware/rateLimiter.ts` as an in-memory
  IP-based limiter suitable for single-node Replit deployments.

## Logging & PII

- Structured logger at `server/logger.ts` with basic PII and secret redaction.
- Request-scoped logging via `loggerMiddleware` attaching a `requestId`.

## Secrets Management

- Secrets are stored in Replit Secrets, not committed in git.
- `.env.example` documents required variables without values.
