# Deploy on Replit

This project is configured for one-click run in Replit using `.replit` and `replit.nix`.

## Development

1. Open the Replit workspace.
2. Ensure secrets are set:
   - `DATABASE_URL`
   - `AI_INTEGRATIONS_OPENAI_API_KEY`
   - `AI_INTEGRATIONS_OPENAI_BASE_URL`
3. In the Shell:
   ```bash
   npm install
   npm run env:check
   npm run db:push
   npm run seed
   npm run dev
   ```
4. Replit's **Run** button is also wired to `npm run dev` by default.

## Production-like

1. In the Shell:
   ```bash
   npm install
   npm run env:check
   npm run db:push
   npm run build
   npm run start
   ```
2. Confirm:
   - `/healthz` returns status `ok`.
   - `/readyz` returns status `ok`.
   - `/metrics` returns Prometheus text.

## First-Run Initializer

- Script: `npm run first-run:init`
  - Validates env (`env:check`)
  - Applies DB schema (`db:push`)
  - Seeds sample data (`seed`)
  - Prints URLs and hints to the console.
