import type { Request, Response, NextFunction } from "express";
import { routeRateLimits, type RateLimitConfig } from "../../config/rateLimits";

type BucketKey = string;

interface BucketState {
  count: number;
  windowStart: number;
}

const buckets = new Map<BucketKey, BucketState>();

function makeRouteKey(method: string, path: string): string {
  return `${method.toUpperCase()} ${path}`;
}

function getConfig(method: string, path: string): RateLimitConfig {
  const key = makeRouteKey(method, path);
  if (routeRateLimits[key]) return routeRateLimits[key];
  return routeRateLimits.DEFAULT;
}

export function rateLimiter(req: Request, res: Response, next: NextFunction) {
  const now = Date.now();
  const ip = (req.ip || (req.headers["x-forwarded-for"] as string) || "unknown")
    .toString()
    .split(",")[0]
    .trim();

  const config = getConfig(req.method, req.path);
  const bucketKey: BucketKey = `${ip}:${req.method}:${req.path}`;
  const existing = buckets.get(bucketKey);

  if (!existing) {
    buckets.set(bucketKey, { count: 1, windowStart: now });
    return next();
  }

  if (now - existing.windowStart > config.windowMs) {
    existing.count = 1;
    existing.windowStart = now;
    buckets.set(bucketKey, existing);
    return next();
  }

  if (existing.count >= config.max) {
    return res.status(429).json({
      code: "RATE_LIMITED",
      message: "Too many requests, please slow down.",
    });
  }

  existing.count += 1;
  buckets.set(bucketKey, existing);
  return next();
}
