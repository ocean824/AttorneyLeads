type LogLevel = "debug" | "info" | "warn" | "error";

interface LogContext {
  requestId?: string;
  route?: string;
  [key: string]: unknown;
}

const SENSITIVE_KEYS = [
  "password",
  "secret",
  "token",
  "apikey",
  "apiKey",
  "authorization",
];

function redact(value: unknown): unknown {
  if (typeof value === "string") {
    if (value.length > 8 && /[A-Za-z0-9]{16,}/.test(value)) {
      return "[redacted]";
    }
    return value;
  }

  if (Array.isArray(value)) {
    return value.map(redact);
  }

  if (value && typeof value === "object") {
    const obj = value as Record<string, unknown>;
    const clone: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj)) {
      if (SENSITIVE_KEYS.some((s) => k.toLowerCase().includes(s.toLowerCase()))) {
        clone[k] = "[redacted]";
      } else {
        clone[k] = redact(v);
      }
    }
    return clone;
  }

  return value;
}

function log(level: LogLevel, message: string, ctx?: LogContext) {
  const payload = {
    level,
    message,
    ts: new Date().toISOString(),
    ...(ctx ? redact(ctx) : {}),
  };
  // eslint-disable-next-line no-console
  console.log(JSON.stringify(payload));
}

export const logger = {
  debug: (message: string, ctx?: LogContext) => log("debug", message, ctx),
  info: (message: string, ctx?: LogContext) => log("info", message, ctx),
  warn: (message: string, ctx?: LogContext) => log("warn", message, ctx),
  error: (message: string, ctx?: LogContext) => log("error", message, ctx),
};
