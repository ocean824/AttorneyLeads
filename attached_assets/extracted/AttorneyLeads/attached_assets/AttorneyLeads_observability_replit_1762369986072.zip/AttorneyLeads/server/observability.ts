import type { Express, Request, Response } from "express";
import { sql } from "drizzle-orm";
import { db } from "./db";
import { arrestRecords, scrapeJobs } from "@shared/schema";
import { logger } from "./logger";

type HealthStatus = {
  status: "ok" | "error";
  checks?: Record<string, unknown>;
};

export function registerObservabilityRoutes(app: Express) {
  app.get("/healthz", async (_req: Request, res: Response) => {
    try {
      // Lightweight DB connectivity check
      await db.select({ id: arrestRecords.id }).from(arrestRecords).limit(1);
      const payload: HealthStatus = { status: "ok" };
      res.json(payload);
    } catch (error) {
      logger.error("healthz_failed", {
        errorMessage: (error as Error).message,
      });
      const payload: HealthStatus = { status: "error" };
      res.status(500).json(payload);
    }
  });

  app.get("/readyz", async (_req: Request, res: Response) => {
    try {
      const [recordsRow] = await db
        .select({ count: sql<number>`count(*)` })
        .from(arrestRecords);

      const [jobsRow] = await db
        .select({ count: sql<number>`count(*)` })
        .from(scrapeJobs);

      const hasOpenAI = !!process.env.AI_INTEGRATIONS_OPENAI_API_KEY;

      const payload: HealthStatus = {
        status: "ok",
        checks: {
          db: true,
          env: {
            openai: hasOpenAI,
          },
          recordCount: recordsRow?.count ?? 0,
          jobCount: jobsRow?.count ?? 0,
        },
      };

      res.json(payload);
    } catch (error) {
      logger.error("readyz_failed", {
        errorMessage: (error as Error).message,
      });
      const payload: HealthStatus = {
        status: "error",
        checks: {
          db: false,
        },
      };
      res.status(500).json(payload);
    }
  });

  app.get("/metrics", async (_req: Request, res: Response) => {
    res.setHeader("Content-Type", "text/plain; version=0.0.4");

    try {
      const [recordsRow] = await db
        .select({ count: sql<number>`count(*)` })
        .from(arrestRecords);
      const [jobsRow] = await db
        .select({ count: sql<number>`count(*)` })
        .from(scrapeJobs);

      const lines = [
        "# HELP attorneyleads_up Application up status.",
        "# TYPE attorneyleads_up gauge",
        "attorneyleads_up 1",
        "# HELP attorneyleads_records_total Total number of arrest records.",
        "# TYPE attorneyleads_records_total gauge",
        `attorneyleads_records_total ${recordsRow?.count ?? 0}`,
        "# HELP attorneyleads_scrape_jobs_total Total number of scrape jobs.",
        "# TYPE attorneyleads_scrape_jobs_total gauge",
        `attorneyleads_scrape_jobs_total ${jobsRow?.count ?? 0}`,
      ];

      res.send(lines.join("\n") + "\n");
    } catch (error) {
      logger.error("metrics_failed", {
        errorMessage: (error as Error).message,
      });

      const lines = [
        "# HELP attorneyleads_up Application up status.",
        "# TYPE attorneyleads_up gauge",
        "attorneyleads_up 0",
      ];

      res.status(500).send(lines.join("\n") + "\n");
    }
  });
}
