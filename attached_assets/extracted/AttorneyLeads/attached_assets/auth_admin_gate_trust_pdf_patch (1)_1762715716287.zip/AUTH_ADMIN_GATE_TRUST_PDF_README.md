
# Patch: Admin Hard-Gated TOTP Setup, Trusted Devices, Printable Backup Codes PDF

This patch builds on the previous 2FA layers.

## Highlights
- **Admin-only hard gate** to set up TOTP before completing login:
  - Enable with `ENFORCE_ADMIN_TOTP_SETUP=true`.
  - Admins without TOTP enabled cannot finish login via email/SMS/backup. They must complete TOTP setup (in a special pre-auth flow).
- **Trusted devices** (remember this device for N days):
  - Server stores a **hashed device token**; client gets an httpOnly cookie.
  - Bypasses 2FA *only if* the user already has TOTP enabled.
  - Manage at `/devices` (list + revoke).
  - Configurable TTL via `TRUSTED_DEVICE_DAYS` (default 30).
- **Printable backup-codes PDF**:
  - `POST /api/auth/backup-codes/pdf` with `{ codes: [...] }` returns a PDF (uses `pdfkit` if installed; otherwise a `.txt`).

## Files
- `shared/schema.ADD_TRUSTED.ts` — `user_trusted_devices` table.
- `server/security/device.ts` — helpers for device tokens.
- `server/export.ts` — generates backup codes PDF (dynamic `pdfkit` import).
- `server/auth-admin-gate-trust.ts` — routes:
  - `POST /api/auth/_post-password` — **use after password verification** to branch into 2FA flows with admin hard gate & device bypass.
  - `POST /api/auth/totp/pending/start` and `POST /api/auth/totp/pending/verify` — TOTP setup during pending login for hard-gated admins.
  - `GET /api/account/devices` and `POST /api/account/devices/:id/revoke`
  - `POST /api/auth/trust-device` — set cookie and store device (call after successful 2FA if checkbox is checked).
  - `POST /api/auth/backup-codes/pdf`
- `server/types/session.d.ts` — extends `pending2fa` with `hardSetup` flag.
- `client/src/pages/devices.tsx` — Trusted Devices UI.
- `client/src/pages/2fa.TRUST_NOTE.txt` — add “Trust this device” checkbox to 2FA pages.
- `client/src/pages/account-security.NOTE.txt` — link to devices and PDF download.

## Env
```
ENFORCE_ADMIN_TOTP_SETUP=true
TRUSTED_DEVICE_DAYS=30
DEVICE_COOKIE_NAME=device

# For PDF (optional)
# npm i pdfkit
```

## How to wire it in
1) **Schema**: merge `shared/schema.ADD_TRUSTED.ts` and run `npm run db:push`.
2) **Server flow**:
   - In your login handler (after verifying email+password & loading `user`), set `req._passwordUser = user` **then** call `POST /api/auth/_post-password` (or inline the logic) to get the 2FA decision payload.
   - If `adminMustSetup2fa` is true, drive the **pending TOTP** setup via `/api/auth/totp/pending/start` → `/api/auth/totp/pending/verify`. This completes login.
   - If normal `requires2fa`, proceed with your existing TOTP/backup/fallback routes.
   - When 2FA succeeds and the user checked “Trust this device”, call `POST /api/auth/trust-device?label=My%20Laptop` to set cookie + save record.
3) **Client**:
   - Add a checkbox to `/2fa` and `/2fa-fallback` to optionally trust the device; if checked, call `/api/auth/trust-device` after 2FA success.
   - Add a link to `/devices` in Account Security to manage trusted devices.
   - After generating backup codes, offer a “Download PDF” button that posts `{ codes }` to `/api/auth/backup-codes/pdf` and downloads the file.
4) **Optional**: `npm i pdfkit` for real PDF output.

> Trusted device bypass is **not** allowed to help an admin skip the initial TOTP setup when the hard gate is on. It only works *after* TOTP is enabled (and only within expiry).
