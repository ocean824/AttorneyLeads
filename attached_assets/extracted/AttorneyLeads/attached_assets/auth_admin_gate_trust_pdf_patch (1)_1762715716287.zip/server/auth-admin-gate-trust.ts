
import type { Express, Request, Response } from "express";
import { db } from "./db";
import { and, eq, lt, isNull } from "drizzle-orm";
import {
  users,
  userBackupCodes,
  userTrustedDevices,
} from "@shared/schema";
import { verifyPassword } from "./security/password";
import { decryptGCM } from "./security/crypto";
import { verifyTotp } from "./security/totp";
import { makeDeviceToken, daysFromEnv } from "./security/device";
import { sendBackupCodesPdf } from "./export";
import { createHash } from "crypto";

const DEVICE_COOKIE = process.env.DEVICE_COOKIE_NAME || "device";

function hashToken(t: string) {
  return createHash("sha256").update(t).digest("hex");
}

function isAdmin(user: any): boolean {
  return (user.role || "user") === "admin";
}

function totpEnabled(user: any): boolean {
  return !!(user.totpEnabled === 1 || user.totp_enabled === 1);
}

function enforceAdminSetup(): boolean {
  return process.env.ENFORCE_ADMIN_TOTP_SETUP === "true";
}

async function maybeBypass2FA(req: Request, user: any): Promise<boolean> {
  // Only bypass when a valid trusted device cookie exists and user already has TOTP enabled.
  if (!totpEnabled(user)) return false;
  const raw = req.cookies?.[DEVICE_COOKIE];
  if (!raw) return false;
  const tokenHash = hashToken(String(raw));
  const now = new Date();
  const rows = await db
    .select()
    .from(userTrustedDevices)
    .where(and(eq(userTrustedDevices.userId, user.id), eq(userTrustedDevices.tokenHash, tokenHash)));
  const d = rows[0] as any;
  if (!d || d.revokedAt || d.expiresAt < now) return false;
  return true;
}

async function trustThisDevice(res: Response, userId: string, label: string | undefined, ip: string, ua: string) {
  const { token, hash } = makeDeviceToken();
  const days = daysFromEnv();
  const expiresAt = new Date(Date.now() + days * 24 * 3600 * 1000);
  await db.insert(userTrustedDevices).values({
    userId,
    tokenHash: hash,
    label,
    ip,
    userAgent: ua,
    expiresAt,
  });
  res.cookie(DEVICE_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: days * 24 * 3600 * 1000,
  });
}

export function registerAuthAdminHardGate(app: Express) {
  // NOTE: This module supplements your existing /api/auth/* routes.

  // Login pre-check middleware: replace your login handler's post-password-success logic with this flow
  app.post("/api/auth/_post-password", async (req, res) => {
    const user = (req as any)._passwordUser; // you should set this after verifying password in your login handler
    if (!user) return res.status(400).json({ error: "Missing user context" });

    // device bypass
    if (await maybeBypass2FA(req, user)) {
      req.session.user = { id: user.id, email: user.email, role: user.role || "user" };
      return res.json({ user: { id: user.id, email: user.email, role: user.role || "user" } });
    }

    const mustHardSetup = enforceAdminSetup() && isAdmin(user) && !totpEnabled(user);

    // Begin pending 2FA session
    req.session.pending2fa = { userId: user.id, hardSetup: mustHardSetup };

    // For hard setup, do NOT allow fallback methods or backup — force TOTP setup
    if (mustHardSetup) {
      return res.json({ requires2fa: true, adminMustSetup2fa: true, methods: { totp: true, backup: false, fallback: { email: false, sms: false } } });
    } else {
      // Normal 2FA stage: allow TOTP/backup/fallback
      const hasPhone = !!user.phone;
      return res.json({ requires2fa: true, methods: { totp: totpEnabled(user), backup: true, fallback: { email: true, sms: hasPhone } } });
    }
  });

  // Pending TOTP setup when hard gated (no full session yet)
  app.post("/api/auth/totp/pending/start", async (req, res) => {
    const p = req.session?.pending2fa;
    if (!p || !p.hardSetup) return res.status(401).json({ error: "No hard-setup pending" });
    const { generateSecret, otpauthURI } = await import("./security/totp");
    const { encryptGCM } = await import("./security/crypto");
    const { users } = await import("@shared/schema");
    const { db } = await import("./db");

    const rows = await db.select().from(users).where(eq(users.id, p.userId));
    const user = rows[0] as any;
    if (!user) return res.status(400).json({ error: "Invalid session" });

    const { secretBase32 } = generateSecret();
    const uri = otpauthURI(process.env.TOTP_ISSUER || "AttorneyLeads", user.email, secretBase32);
    const qr = `https://chart.googleapis.com/chart?cht=qr&chs=256x256&chl=${encodeURIComponent(uri)}`;
    (req.session as any).totpSetup = { secretBase32 };
    res.json({ otpauthURI: uri, qrImageUrl: qr, secretBase32 });
  });

  app.post("/api/auth/totp/pending/verify", async (req, res) => {
    const p = req.session?.pending2fa as any;
    const setup = (req.session as any).totpSetup;
    if (!p || !p.hardSetup || !setup?.secretBase32) return res.status(401).json({ error: "No setup in progress" });
    const token = String(req.body?.token || "");
    if (!token) return res.status(400).json({ error: "Missing token" });

    const { verifyTotp } = await import("./security/totp");
    if (!verifyTotp(token, setup.secretBase32, 1)) return res.status(401).json({ error: "Invalid code" });

    const { encryptGCM } = await import("./security/crypto");
    const { users } = await import("@shared/schema");
    const { db } = await import("./db");

    const enc = encryptGCM(setup.secretBase32);
    const [user] = await db.update(users).set({ totpSecretEnc: enc as any, totpEnabled: 1 as any }).where(eq(users.id, p.userId)).returning();
    delete (req.session as any).totpSetup;

    // Now that TOTP is enabled, finalize login immediately
    req.session.user = { id: user!.id, email: user!.email, role: (user as any).role || "user" };
    delete (req.session as any).pending2fa;
    res.json({ user: { id: user!.id, email: user!.email, role: (user as any).role || "user" } });
  });

  // Device trust management (requires full session)
  app.get("/api/account/devices", async (req, res) => {
    const u = req.session?.user;
    if (!u) return res.status(401).json({ error: "Unauthorized" });
    const rows = await db.select().from(userTrustedDevices).where(eq(userTrustedDevices.userId, u.id));
    res.json(rows);
  });

  app.post("/api/account/devices/:id/revoke", async (req, res) => {
    const u = req.session?.user;
    if (!u) return res.status(401).json({ error: "Unauthorized" });
    const id = req.params.id;
    const [row] = await db.update(userTrustedDevices).set({ revokedAt: new Date() }).where(and(eq(userTrustedDevices.id, id), eq(userTrustedDevices.userId, u.id))).returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  });

  // Trust current device after successful 2FA (call this with ?label=My%20Laptop and it will set cookie)
  app.post("/api/auth/trust-device", async (req, res) => {
    const u = req.session?.user || (req.session as any)?.pending2fa;
    if (!u) return res.status(401).json({ error: "Unauthorized" });
    // Allow during pending2fa (after they pass 2FA you'd call this again to seal trust)
    const label = String(req.query.label || "");
    await trustThisDevice(
      res,
      u.userId || u.id,
      label || undefined,
      (req.headers["x-forwarded-for"] as string || req.socket.remoteAddress || "").toString(),
      String(req.headers["user-agent"] || "")
    );
    res.json({ trusted: true, days: daysFromEnv() });
  });

  // Printable PDF for backup codes (client posts the fresh codes they just generated)
  app.post("/api/auth/backup-codes/pdf", async (req, res) => {
    const u = req.session?.user;
    if (!u) return res.status(401).json({ error: "Unauthorized" });
    const codes = Array.isArray(req.body?.codes) ? req.body.codes.map(String) : [];
    if (!codes.length) return res.status(400).json({ error: "No codes" });
    await sendBackupCodesPdf(res, u.email, codes);
  });
}
