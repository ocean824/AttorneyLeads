
import { PrivateRoute } from "@/components/auth/private-route";
export default function Dashboard() {
  return (
    <PrivateRoute>
      <div className="p-6">
        <h1 className="text-2xl font-semibold mb-2">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Only visible after login.</p>
      </div>
    </PrivateRoute>
  );
}
