
# Landing Page = Login Only + Protected Dashboard

This patch makes `/` a clean **login-only landing page** and forces `/dashboard` through auth.

## What you got
- `client/src/pages/login-landing.tsx` — minimalist landing page with the login panel
- `client/src/pages/dashboard.tsx` — placeholder, wrapped in `PrivateRoute`
- `client/src/components/auth/private-route.tsx` — client-side guard using `/api/auth/whoami`
- `client/src/components/layout/header.tsx` — header **hidden** on landing when logged out
- `server/middleware/protectDashboard.ts` — server-side redirect guard for direct GET `/dashboard`
- `client/src/App.ROUTES.LANDING_ONLY.txt` — router snippet to wire routes

## Wire up
1. **Client routes** — update your `App.tsx` router using the snippet in `client/src/App.ROUTES.LANDING_ONLY.txt`.
2. **Header** — replace/merge your header with the provided one (hides on landing when logged out).
3. **Server** — in your server bootstrap (after sessions), add:
```ts
import { registerDashboardGuard } from "./server/middleware/protectDashboard";
registerDashboardGuard(app);
```
4. Done. `/` shows only the login panel; `/dashboard` is inaccessible without a session.
