
# README Badge Auto-Commit (CI)

This updates your existing CI to:
- Run the **badge insertion script** after **Pages** deploy
- Commit the updated **README.md** back to `main`
- Use `[skip ci]` in the commit message to avoid recursive CI loops

## Requirements
- `scripts/insert-coverage-badge.mjs` present in your repo (shipped in the previous patch)
- CI publishes `public/docs/coverage-badge.json` to GitHub Pages (already set up)

## How it works
1. `build` runs tests/coverage and generates OpenAPI.
2. `deploy` publishes `public/docs/` (including `coverage-badge.json`) to Pages.
3. `post-deploy-readme-badge` checks out the repo with write credentials, runs the badge insert script, and commits **only if README changed**. The commit includes `[skip ci]` to prevent loops.
