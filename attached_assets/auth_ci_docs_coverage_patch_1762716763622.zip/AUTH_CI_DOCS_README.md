
# CI + Coverage Gate + Auto Docs + Extra Tests

This patch adds:

- **Coverage thresholds** in Vitest (fail build if under thresholds)
- **OpenAPI generator** (server/docs/generateOpenAPI.mjs) and **/api/docs** mount via ReDoc
- **Strict docs gate** in CI (fail if 0 paths)
- **Extra E2E spec** covering backup codes PDF and Email/SMS fallback (with a test-only OTP token return)

## Install
```bash
npm i -D vitest supertest better-sqlite3 drizzle-orm zod
# Optional (for pretty PDF in production; tests accept text fallback):
npm i pdfkit
```

## Scripts (package.json)
```json
{
  "scripts": {
    "ci:run:full": "node scripts/ci.run.full.mjs",
    "docs:build": "node server/docs/generateOpenAPI.mjs",
    "test:e2e": "vitest run -c vitest.config.ts --dir tests"
  }
}
```

## Server bootstrap
In your `server/index.ts` (or wherever you create `app`), register docs routes:
```ts
import { registerDocsRoutes } from "./server/docs/mountDocs";
registerDocsRoutes(app);
```

## Test-only OTP token
To allow the E2E to verify Email/SMS OTP, enable the test token echo:
```
ALLOW_TEST_OTP_RESPONSE=true
```

Update your `/api/auth/otp/send` handler (already noted in the included patch note) to include the token in the response **only** when `ALLOW_TEST_OTP_RESPONSE=true`.

## Run locally
```bash
npm run test:e2e        # run both specs with coverage
npm run docs:build      # build /public/docs/openapi.json
```

## CI
Use `npm run ci:run:full` to:
1) Run tests with coverage (thresholds enforced)
2) Generate OpenAPI
3) Fail if OpenAPI contains 0 paths
