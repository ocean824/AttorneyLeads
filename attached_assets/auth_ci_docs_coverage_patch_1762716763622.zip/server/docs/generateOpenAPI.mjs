
import fs from "fs";
import path from "path";

const pathsManifestPath = path.resolve("server/docs/paths.json");
const outDir = path.resolve("public/docs");
const outFile = path.join(outDir, "openapi.json");

const base = {
  openapi: "3.0.3",
  info: {
    title: process.env.OPENAPI_TITLE || "AttorneyLeads API",
    version: process.env.OPENAPI_VERSION || "1.0.0",
  },
  servers: [{ url: process.env.APP_URL || "http://localhost:3000" }],
  paths: {},
  components: { securitySchemes: { cookieAuth: { type: "apiKey", in: "cookie", name: "connect.sid" } } },
  security: [{ cookieAuth: [] }],
};

const manifest = JSON.parse(fs.readFileSync(pathsManifestPath, "utf-8"));
if (!manifest.paths || !Object.keys(manifest.paths).length) {
  console.error("0 routes found in paths.json — please verify server/docs/paths.json");
  process.exit(2);
}

for (const [p, methods] of Object.entries(manifest.paths)) {
  base.paths[p] = {};
  for (const m of methods) {
    base.paths[p][m.toLowerCase()] = {
      summary: `${m} ${p}`,
      responses: { "200": { description: "OK" } },
    };
  }
}

fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(outFile, JSON.stringify(base, null, 2));
console.log("OpenAPI written:", outFile);
