
import type { Express, Request, Response } from "express";
import fs from "fs";
import path from "path";

export function registerDocsRoutes(app: Express) {
  const outDir = path.resolve("public/docs");
  const specPath = path.join(outDir, "openapi.json");

  app.get("/api/docs/openapi.json", (_req: Request, res: Response) => {
    try {
      const json = fs.readFileSync(specPath, "utf-8");
      res.setHeader("Content-Type", "application/json");
      res.send(json);
    } catch {
      res.status(500).json({ error: "OpenAPI spec not found. Run: node server/docs/generateOpenAPI.mjs" });
    }
  });

  app.get("/api/docs", (_req: Request, res: Response) => {
    const html = `<!DOCTYPE html>
<html>
<head><title>API Docs</title></head>
<body>
  <redoc spec-url="/api/docs/openapi.json"></redoc>
  <script src="https://cdn.redoc.ly/redoc/latest/bundles/redoc.standalone.js"></script>
</body>
</html>`;
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.send(html);
  });
}
