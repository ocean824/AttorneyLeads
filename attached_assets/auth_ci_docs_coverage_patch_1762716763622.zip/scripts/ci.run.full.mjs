
import { execSync } from "child_process";
import fs from "fs";

function run(cmd) {
  console.log("$", cmd);
  execSync(cmd, { stdio: "inherit", env: { ...process.env, CI: "true" } });
}

try {
  // 1) Run tests with coverage
  run("vitest run -c vitest.config.ts --dir tests");

  // 2) Build OpenAPI
  run("node server/docs/generateOpenAPI.mjs");

  // 3) Strict docs gate: ensure non-empty paths
  const spec = JSON.parse(fs.readFileSync("public/docs/openapi.json", "utf-8"));
  const paths = spec.paths || {};
  const count = Object.keys(paths).length;
  if (!count) {
    console.error("0 routes found in OpenAPI spec — please verify server/docs/paths.json");
    process.exit(3);
  }
  console.log("OpenAPI paths:", count);
  console.log("CI pipeline OK.");
} catch (e) {
  console.error("CI failed:", e?.message || e);
  process.exit(1);
}
