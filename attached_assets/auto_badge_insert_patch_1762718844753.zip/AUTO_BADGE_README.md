
# README Coverage Badge Auto-Insert

This script inserts a Shields coverage badge under the first H1 in `README.md`, or at the very top if no H1 exists. It **preserves your headings** and skips insertion if a coverage badge is already present.

## Install
No extra deps — uses Node built-ins.

## Usage
```bash
node scripts/insert-coverage-badge.mjs           # auto-detects USER/REPO from git remote
node scripts/insert-coverage-badge.mjs --dry     # print result without writing
node scripts/insert-coverage-badge.mjs --user <USER> --repo <REPO>
# or via envs:
GITHUB_USER=<USER> GITHUB_REPO=<REPO> node scripts/insert-coverage-badge.mjs
```

## What it inserts
```md
![coverage](https://img.shields.io/endpoint?url=https://<USER>.github.io/<REPO>/coverage-badge.json)
```

> The JSON endpoint above is created by your CI (see previous patch) at `public/docs/coverage-badge.json` and published to GitHub Pages.

## Add to package.json
```json
{
  "scripts": {
    "badge:insert": "node scripts/insert-coverage-badge.mjs"
  }
}
```
