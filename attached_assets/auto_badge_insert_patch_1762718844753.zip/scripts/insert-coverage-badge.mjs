
// scripts/insert-coverage-badge.mjs
// Auto-insert a Shields coverage badge under the H1 in README.md.
// Usage:
//   node scripts/insert-coverage-badge.mjs [--user USER] [--repo REPO] [--label coverage] [--dry]
//
// Behavior:
// - Detects <USER>/<REPO> from `git remote get-url origin` unless overridden.
// - Inserts the badge line `![coverage](https://img.shields.io/endpoint?url=https://USER.github.io/REPO/coverage-badge.json)`
//   directly *under the first H1* (`# Title`) or at the very top if no H1 exists.
// - Skips insertion if a coverage badge for `coverage-badge.json` already exists.
// - Creates a backup at README.md.bak before writing.
//
// Tip: run this in CI after publishing Pages so the badge URL is valid.
import fs from "fs";
import { execSync } from "child_process";
import path from "path";

function parseArgs() {
  const args = process.argv.slice(2);
  const out = { user: null, repo: null, label: "coverage", dry: false };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--user") out.user = args[++i];
    else if (a === "--repo") out.repo = args[++i];
    else if (a === "--label") out.label = args[++i];
    else if (a === "--dry") out.dry = true;
  }
  return out;
}

function getGitRemote() {
  try {
    const raw = execSync("git config --get remote.origin.url", { stdio: ["ignore", "pipe", "ignore"] })
      .toString()
      .trim();
    return raw || null;
  } catch {
    return null;
  }
}

function deriveUserRepo(remoteUrl) {
  if (!remoteUrl) return { user: null, repo: null };
  // Patterns:
  // https://github.com/<USER>/<REPO>.git
  // git@github.com:<USER>/<REPO>.git
  let m = null;
  m = remoteUrl.match(/github\.com[/:]([^/]+)\/([^/]+?)(?:\.git)?$/i);
  if (m) return { user: m[1], repo: m[2].replace(/\.git$/i, "") };
  return { user: null, repo: null };
}

function findH1Index(lines) {
  for (let i = 0; i < lines.length; i++) {
    if (/^#\s+/.test(lines[i])) return i;
  }
  return -1;
}

function hasCoverageBadge(content) {
  // Looks for any shields endpoint that targets coverage-badge.json
  return /img\.shields\.io\/endpoint\?url=https:\/\/[^)]+\/coverage-badge\.json/i.test(content);
}

function insertBadge(content, badgeLine) {
  const lines = content.split(/\r?\n/);
  const h1 = findH1Index(lines);
  const insertion = [badgeLine, ""]; // badge line + blank line
  if (h1 >= 0) {
    const insertAt = Math.min(h1 + 1, lines.length);
    // If there's already a blank line right after H1, keep spacing consistent
    if (lines[insertAt] && lines[insertAt].trim() === "") {
      // insert after the existing blank line
      lines.splice(insertAt + 1, 0, ...insertion);
    } else {
      lines.splice(insertAt, 0, "", ...insertion);
    }
    return lines.join("\n");
  } else {
    // No H1 — prepend
    return [badgeLine, "", content].join("\n");
  }
}

(function main() {
  const args = parseArgs();
  const remote = getGitRemote();
  const inferred = deriveUserRepo(remote);
  const user = args.user || process.env.GITHUB_USER || inferred.user;
  const repo = args.repo || process.env.GITHUB_REPO || inferred.repo;
  const label = args.label || "coverage";

  if (!user || !repo) {
    console.error("❌ Could not determine <USER>/<REPO>. Pass --user/--repo or set GITHUB_USER/GITHUB_REPO envs.");
    process.exit(2);
  }

  const readmePath = path.resolve("README.md");
  if (!fs.existsSync(readmePath)) {
    console.error("❌ README.md not found in project root.");
    process.exit(3);
  }

  const badgeUrl = `https://img.shields.io/endpoint?url=https://${user}.github.io/${repo}/coverage-badge.json`;
  const badgeLine = `![${label}](${badgeUrl})`;

  const content = fs.readFileSync(readmePath, "utf-8");
  if (hasCoverageBadge(content)) {
    console.log("ℹ️ Coverage badge already present — nothing to do.");
    process.exit(0);
  }

  const updated = insertBadge(content, badgeLine);
  if (args.dry) {
    console.log("---- DRY RUN updated README.md ----\n");
    console.log(updated);
    process.exit(0);
  }

  // backup then write
  fs.writeFileSync(readmePath + ".bak", content, "utf-8");
  fs.writeFileSync(readmePath, updated, "utf-8");
  console.log(`✅ Inserted badge under H1 with URL: ${badgeUrl}`);
})();
