
import express from "express";
import session from "express-session";
import { registerAuthRoutes } from "../auth-routes";

export function createTestApp() {
  const app = express();
  app.use(express.json());
  app.use(session({
    secret: "test-secret",
    resave: false,
    saveUninitialized: false,
  }));
  registerAuthRoutes(app);
  return app;
}
