
# E2E Test Suite (Vitest + Supertest)

Covers:
- Admin bootstrap
- Admin hard‑gated TOTP setup (no fallback)
- `/api/auth/whoami` after login
- Trust device + 2FA bypass on next login

## Install dev deps
```bash
npm i -D vitest supertest better-sqlite3 drizzle-orm zod
```

> If your project already includes `drizzle-orm`/`zod`, you can omit them here.

## Run
```bash
npm run test:e2e
```
Add this to your `package.json` scripts:
```json
{
  "scripts": {
    "test:e2e": "vitest run -c vitest.config.ts --dir tests"
  }
}
```

## How it works
- `vitest.config.ts` aliases `@shared/schema` and `./db` to in‑memory SQLite mocks so tests don’t touch your prod DB.
- The test spins up a tiny Express app via `server/test/app.factory.ts` and mounts your consolidated `registerAuthRoutes`.
- The suite uses a single Supertest **agent** to persist cookies across steps (session + trusted device cookie).
- Environment toggles:
  - `ENFORCE_2FA_FOR_ADMINS=true`
  - `ENFORCE_ADMIN_TOTP_SETUP=true`
  - `AUTH_ENC_KEY=...`
- No SMTP/Twilio required; code paths fall back to console.

## Files
- `vitest.config.ts` — alias test modules
- `server/test/schema.mock.ts` — Drizzle SQLite schema for tests
- `server/test/db.mock.ts` — in‑memory database
- `server/test/app.factory.ts` — builds Express app with session + routes
- `tests/auth.e2e.test.ts` — the E2E spec
