
# Badges

Replace `<USER>` and `<REPO>` below with your GitHub org/user and repo name. The badge reads from GitHub Pages, which the CI publishes at `public/docs/coverage-badge.json`:

![coverage](https://img.shields.io/endpoint?url=https://<USER>.github.io/<REPO>/coverage-badge.json)

> The badge updates on every push to `main` when CI runs.
