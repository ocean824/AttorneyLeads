
import { execSync } from "child_process";
import fs from "fs";
import path from "path";

function run(cmd) {
  console.log("$", cmd);
  execSync(cmd, { stdio: "inherit", env: { ...process.env, CI: "true" } });
}

function badgeColor(pct) {
  if (pct >= 90) return "brightgreen";
  if (pct >= 80) return "green";
  if (pct >= 70) return "yellow";
  if (pct >= 50) return "orange";
  return "red";
}

try {
  // 1) Run tests with coverage (vitest writes coverage/coverage-summary.json)
  run("vitest run -c vitest.config.ts --dir tests");

  // 2) Build OpenAPI
  run("node server/docs/generateOpenAPI.mjs");

  // 3) Strict docs gate
  const spec = JSON.parse(fs.readFileSync("public/docs/openapi.json", "utf-8"));
  const count = Object.keys(spec.paths || {}).length;
  if (!count) {
    console.error("0 routes found in OpenAPI spec — please verify server/docs/paths.json");
    process.exit(3);
  }
  console.log("OpenAPI paths:", count);

  // 4) Generate Shields-compatible coverage badge JSON on Pages
  const covPath = path.resolve("coverage/coverage-summary.json");
  let pct = 0;
  if (fs.existsSync(covPath)) {
    const summary = JSON.parse(fs.readFileSync(covPath, "utf-8"));
    const lines = summary.total?.lines?.pct ?? 0;
    pct = Math.round(lines);
    console.log("Coverage (lines):", lines);
  } else {
    console.warn("coverage/coverage-summary.json not found — badge will show 0%");
  }
  const badge = {
    schemaVersion: 1,
    label: "coverage",
    message: `${pct}%`,
    color: badgeColor(pct),
  };
  const outDir = path.resolve("public/docs");
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, "coverage-badge.json"), JSON.stringify(badge, null, 2));

  // 5) Optional index.html for GitHub Pages
  const indexHtml = `<!doctype html><html><head><meta charset="utf-8"><title>API Docs</title></head>
  <body style="font-family: sans-serif; margin:2rem;">
    <h1>Docs & Coverage</h1>
    <p><a href="./openapi.json">openapi.json</a></p>
    <p><img alt="coverage" src="https://img.shields.io/endpoint?url=${process.env.PAGES_BASE_URL || "https://<USER>.github.io/<REPO>"}${process.env.PAGES_BASE_URL ? "" : "/<REPO>"} /coverage-badge.json"></p>
  </body></html>`;
  fs.writeFileSync(path.join(outDir, "index.html"), indexHtml);

  console.log("CI pipeline OK.");
} catch (e) {
  console.error("CI failed:", e?.message || e);
  process.exit(1);
}
