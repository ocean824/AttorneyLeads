
# CI + GitHub Pages + Replit Nix

This patch adds:
- **GitHub Actions** workflow that runs tests with coverage & builds OpenAPI, uploads coverage as an artifact, and publishes **/public/docs/openapi.json** to **GitHub Pages**.
- **Replit Nix** environment to ensure Node 20 + build tools for native modules.
- A simple **Replit CI script** you can run inside the shell to execute the same full CI locally.

## GitHub Pages
1. In your repository settings, enable **Pages** (Build and deployment → Source: GitHub Actions).
2. Push to `main`. The workflow will:
   - Run `npm run ci:run:full`
   - Upload `coverage/` as a downloadable artifact
   - Publish `public/docs/` (contains `openapi.json`) to Pages
3. Your docs will live at:
   - `https://<your-org-or-user>.github.io/<your-repo>/openapi.json`
   - `https://<your-org-or-user>.github.io/<your-repo>/` (index is a directory listing unless you add an HTML front page)

> The CI creates `public/docs/openapi.json` using `server/docs/generateOpenAPI.mjs` and fails if there are 0 paths.

## Replit
- `replit.nix` pins Node 20 and build toolchain for modules like `better-sqlite3`.
- `.replit` defines a unit test hook to run CI:
  ```bash
  bash scripts/replit-ci.sh
  ```

## Scripts (ensure these exist in package.json)
```json
{
  "scripts": {
    "ci:run:full": "node scripts/ci.run.full.mjs",
    "docs:build": "node server/docs/generateOpenAPI.mjs",
    "test:e2e": "vitest run -c vitest.config.ts --dir tests",
    "dev": "node server/index.js"
  }
}
```

If your dev entry point is different, update `.replit`'s `run` command accordingly.
