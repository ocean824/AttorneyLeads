
#!/usr/bin/env bash
set -euo pipefail
echo "[Replit CI] Installing dependencies…"
npm ci
echo "[Replit CI] Running full CI (tests + coverage + docs)…"
npm run ci:run:full
echo "[Replit CI] Done."
