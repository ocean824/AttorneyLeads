
{ pkgs }: {
  deps = [
    pkgs.nodejs_20
    pkgs.python311
    pkgs.gnumake
    pkgs.gcc
    pkgs.pkg-config
    pkgs.openssl
    pkgs.git
  ];
}
